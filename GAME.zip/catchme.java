import java.awt.*; 
import java.awt.event.*;
import java.awt.image.*;
import java.io.File;
//import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*; 

 
class catchme extends Frame {

	JButton btn;
	Random r;
	catchme() 
        {
		setLayout(null);
		r=new Random();
                
                Toolkit t=Toolkit.getDefaultToolkit();
                Image i=t.getImage("C:\\Users\\taran\\OneDrive\\Documents\\NetBeansProjects\\mavenproject1\\src\\main\\java\\theif.png");
		Image j=i.getScaledInstance(250, 250, Image.SCALE_DEFAULT);
//                BufferedImage tempPNG = ImageIO.read(new File("C:\\Users\\taran\\OneDrive\\Documents\\NetBeansProjects\\mavenproject1\\src\\main\\java\\theif.png"));
//                final int color = tempPNG.getRGB(0, 0);
//
//                final Image imageWithTransparency = makeColorTransparent(tempPNG, new Color(color));
                               
                btn=new JButton( new ImageIcon(j));
		
                btn.setBounds(250,250,250,250);
		
		add(btn);
	
		setBounds(400,400,1200,1200);
		
		btn.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent me){
				btn.setLocation(8+r.nextInt(1300),31+r.nextInt(700));
			}
		});
		addMouseMotionListener(new MouseMotionAdapter(){
			public void mouseMoved(MouseEvent me){
				setBackground(Color.blue);
				setTitle(me.getX()+","+me.getY());
			}
		});
                btn.addActionListener((java.awt.event.ActionEvent evt) -> {
                    
                    
                    // You Won Page
                    
                    
                });
                
		setVisible(true);
	}
        
//        public static BufferedImage imageToBufferedImage(final Image image)
//        {
//            final BufferedImage bufferedImage =
//            new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);
//            final Graphics2D g2 = bufferedImage.createGraphics();
//            g2.drawImage(image, 0, 0, null);
//            g2.dispose();
//            return bufferedImage;
//        }
//        public static Image makeColorTransparent(final BufferedImage im, final Color color)
//        {
//            final ImageFilter filter = new RGBImageFilter()
//            {
//         // the color we are looking for (white)... Alpha bits are set to opaque
//                public int markerRGB = color.getRGB() | 0xFFFFFFFF;
//
//                public final int filterRGB(final int x, final int y, final int rgb)
//                    {
//                        if ((rgb | 0xFF000000) == markerRGB)
//                        {
//               // Mark the alpha bits as zero - transparent
//                            return 0x00FFFFFF & rgb;
//                        }
//                        else
//                        {
//               // nothing to do
//                           return rgb;
//                        }
//                    }
//             };
//
//            final ImageProducer ip = new FilteredImageSource(im.getSource(), filter);
//            return Toolkit.getDefaultToolkit().createImage(ip);
//        }
}