public class genout{

    public genout() {
    }
    public static void main(String ag[]){
    	new Details();
        new leaderboard();
        //new catchme();
       		
    }
    
}


