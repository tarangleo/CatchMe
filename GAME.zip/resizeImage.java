import java.awt.*; 
import java.awt.image.BufferedImage;
public class resizeImage {
    
    }
}
    
}
